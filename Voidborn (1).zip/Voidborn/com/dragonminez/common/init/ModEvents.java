package com.dragonminez.common.init;

import com.dragonminez.client.render.VoidedCatRenderer;
import com.dragonminez.common.entity.VoidedCatEntity;
import com.dragonminez.common.init.entities.ModEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "voidborn", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.VOIDED_CAT.get(), VoidedCatEntity.createAttributes());
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.VOIDED_CAT.get(), VoidedCatRenderer::new);
    }
}
