package com.dragonminez.client.model;

import com.dragonminez.common.entity.VoidedCatEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class VoidedCatModel extends GeoModel<VoidedCatEntity> {
    @Override
    public ResourceLocation getModelResource(VoidedCatEntity animatable) {
        return new ResourceLocation("voidborn", "geo/voided_cat.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(VoidedCatEntity animatable) {
        return new ResourceLocation("voidborn", "textures/entity/voided_cat.png");
    }

    @Override
    public ResourceLocation getAnimationResource(VoidedCatEntity animatable) {
        return new ResourceLocation("voidborn", "animations/voided_cat.animation.json");
    }
}
