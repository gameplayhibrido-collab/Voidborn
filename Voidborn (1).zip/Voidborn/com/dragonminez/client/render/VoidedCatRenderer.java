package com.dragonminez.client.render;

import com.dragonminez.client.model.VoidedCatModel;
import com.dragonminez.common.entity.VoidedCatEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class VoidedCatRenderer extends GeoEntityRenderer<VoidedCatEntity> {
    public VoidedCatRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new VoidedCatModel());
    }
}
