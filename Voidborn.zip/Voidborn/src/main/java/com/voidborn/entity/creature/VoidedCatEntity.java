package com.voidborn.entity.creature;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public class VoidedCatEntity extends Monster {

    public VoidedCatEntity(
            EntityType<? extends Monster> type,
            Level level
    ) {
        super(type, level);
    }


    public static AttributeSupplier.Builder createAttributes() {

        return Monster.createMonsterAttributes()

                .add(Attributes.MAX_HEALTH, 500.0D)

                .add(Attributes.ATTACK_DAMAGE, 25.0D)

                .add(Attributes.MOVEMENT_SPEED, 0.30D)

                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)

                .add(Attributes.ARMOR, 10.0D)

                .add(Attributes.ARMOR_TOUGHNESS, 8.0D);
    }

}