package com.voidborn.registry;

import com.voidborn.entity.creature.VoidedCatEntity;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

@Mod.EventBusSubscriber(modid = "voidborn", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntityAttributes {

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {

        event.put(
                ModEntities.VOIDED_CAT.get(),
                VoidedCatEntity.createAttributes().build()
        );

    }

}