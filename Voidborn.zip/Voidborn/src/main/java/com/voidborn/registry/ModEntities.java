package com.voidborn.registry;

import com.voidborn.Voidborn;
import com.voidborn.entity.creature.VoidedCatEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;


public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(
                    ForgeRegistries.ENTITY_TYPES,
                    Voidborn.MOD_ID
            );


    public static final RegistryObject<EntityType<VoidedCatEntity>> VOIDED_CAT =
            ENTITIES.register(
                    "voided_cat",
                    () -> EntityType.Builder.of(
                            VoidedCatEntity::new,
                            MobCategory.MONSTER
                    )
                    .sized(1.8F, 2.2F)
                    .build("voided_cat")
            );

}