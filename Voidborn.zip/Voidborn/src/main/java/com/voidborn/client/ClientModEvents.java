package com.voidborn.client;

import com.voidborn.Voidborn;
import com.voidborn.client.render.VoidedCatRenderer;
import com.voidborn.registry.ModEntities;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.EntityRenderersEvent;

@Mod.EventBusSubscriber(
        modid = Voidborn.MOD_ID,
        value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD
)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {

        event.registerEntityRenderer(
                ModEntities.VOIDED_CAT.get(),
                VoidedCatRenderer::new
        );

    }
}