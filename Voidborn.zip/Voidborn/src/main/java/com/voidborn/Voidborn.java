package com.voidborn;

import com.voidborn.registry.ModEntities;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Voidborn.MOD_ID)
public class Voidborn {

    public static final String MOD_ID = "voidborn";

    public Voidborn() {

        ModEntities.ENTITIES.register(
                FMLJavaModLoadingContext.get()
                        .getModEventBus()
        );

    }
}